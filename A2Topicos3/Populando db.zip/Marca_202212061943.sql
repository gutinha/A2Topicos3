INSERT INTO Topicos3.dbo.Marca (nome,descricao,imagem) VALUES
	 (N'Chevrolet',N'Carrinho',NULL);
