INSERT INTO Topicos3.dbo.Revisao (descricao,dataRevisao,carro_id,usuario_id,status) VALUES
	 (N'trocar vela','2022-12-07 00:00:00.0',1,3,N'Agendada');
