INSERT INTO Topicos3.dbo.Endereco (endereco,numero,complemento,bairro,cidade,estado,cep,Usuario_id) VALUES
	 (N'1004 sul alameda 9',4,N'residencial vila mariana apto 305',N'Plano Diretor Sul',N'Palmas',N'TO',N'77023498',NULL);
