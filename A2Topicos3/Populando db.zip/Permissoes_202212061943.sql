INSERT INTO Topicos3.dbo.Permissoes (permissao,id_usuario) VALUES
	 (N'User',3),
	 (N'Admin',4);
