INSERT INTO Topicos3.dbo.Carro (nome,modelo,anoModelo,anoFabricacao,cavalos,litrosMotor,quantPortas,status,marca_id,imagem) VALUES
	 (N'Onix',N'2022','2022-12-01 00:00:00.0','2022-06-15 00:00:00.0',222,80,4,NULL,1,NULL);
